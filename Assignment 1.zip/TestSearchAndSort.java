import java.util.Arrays;
import java.util.Random;

public class TestSearchAndSort {

    public static void main (String[] args) {
        
        // create array and populate and array with random numbers for the size of 100
        int size1 = 100;
        int[] testData1 = new int[size1];
        Random rndm1 = new Random(); // use a Random object to generate data
        for (int idx = 0; idx < size1; idx++) {
            testData1[idx] = rndm1.nextInt(100); // Random integers between 0 & 100
        }
                         
        // create array and populate and array with random numbers for the size of 1000
        int size = 1000;
        int[] testData = new int[size];
        Random rndm = new Random(); // use a Random object to generate data
        for (int idx = 0; idx < size; idx++) {
            testData[idx] = rndm.nextInt(1000); // Random integers between 0 & 1000
        }
        // create array and populate and array with random numbers for the size of 10000
        int size2 = 10000;
        int[] testData2 = new int[size2];
        Random rndm2 = new Random(); // use a Random object to generate data
        for (int idx = 0; idx < size2; idx++) {
            testData2[idx] = rndm2.nextInt(10000); // Random integers between 0 & 10000
        }
        // Declare a SearchReturn and SortReturn variable to use below
        SearchReturn srchReturn;
        SortReturn sr; 

        // Sort the array with bubble sort and print results for 100, 1000, 10000  
        sr = Sort.bubble(testData1);
        System.out.println(sr.toString());
        sr = Sort.bubble(testData);
        System.out.println(sr.toString()); // display the performance info
        sr = Sort.bubble(testData2);
        System.out.println(sr.toString());
        
        // Sort the array with selection sort and print results for 100, 1000, 10000        
        sr = Sort.selection(testData1);
        System.out.println(sr.toString()); 
        sr = Sort.selection(testData);
        System.out.println(sr.toString()); 
        sr = Sort.selection(testData2);
        System.out.println(sr.toString()); 
        
        // Sort the array with inset sort and print results for 100, 1000, 10000        
        sr = Sort.insert(testData1);
        System.out.println(sr.toString());
        sr = Sort.insert(testData);
        System.out.println(sr.toString()); 
        sr = Sort.insert(testData2);
        System.out.println(sr.toString()); 
        // Searches -- pull an element out of the array (e.g. testData[position])
        // so that it's known to exist in the array
        
        // Search for an element that is known to be in the 10% position
//linear        
        srchReturn = Search.linear(testData1,testData1[size1/10]);
        System.out.println(srchReturn.toString());
        srchReturn = Search.linear(testData,testData[size/10]);
        System.out.println(srchReturn.toString()); // display the performance info
        srchReturn = Search.linear(testData2,testData2[size2/10]);
        System.out.println(srchReturn.toString());
            
//binary
        srchReturn = Search.binary(testData1,testData1[(int)(size1*0.1)]);
        System.out.println(srchReturn.toString()); 
        srchReturn = Search.binary(testData,testData[(int)(size*0.10)]);
        System.out.println(srchReturn.toString()); 
        srchReturn = Search.binary(testData2,testData2[(int)(size2*0.10)]);
        System.out.println(srchReturn.toString()); 
        
        // Search for an element that is known to be in the 50% position
//linear       
        srchReturn = Search.linear(testData1,testData1[size1/2]);
        System.out.println(srchReturn.toString());
        srchReturn = Search.linear(testData,testData[size/2]);
        System.out.println(srchReturn.toString()); // display the performance info
        srchReturn = Search.linear(testData2,testData2[size2/2]);
        System.out.println(srchReturn.toString());
//binary 
        srchReturn = Search.binary(testData1,testData1[size1/2]);
        System.out.println(srchReturn.toString());
        srchReturn = Search.binary(testData,testData[size/2]);
        System.out.println(srchReturn.toString()); // display the performance info
        srchReturn = Search.binary(testData2,testData2[size2/2]);
        System.out.println(srchReturn.toString());
        
        // Search for an element that is known to be in the 90% position
//linear        
        srchReturn = Search.linear(testData1,testData1[(int)(size1*0.9)]);
        System.out.println(srchReturn.toString());
        srchReturn = Search.linear(testData,testData[(int)(size*0.9)]);
        System.out.println(srchReturn.toString()); // display the performance info
        srchReturn = Search.linear(testData2,testData2[(int)(size2*0.9)]);
        System.out.println(srchReturn.toString());
//binary
        srchReturn = Search.binary(testData1,testData1[(int)(size1*0.9)]);
        System.out.println(srchReturn.toString());
        srchReturn = Search.binary(testData,testData[(int)(size*0.9)]);
        System.out.println(srchReturn.toString()); // display the performance info
        srchReturn = Search.binary(testData2,testData2[(int)(size2*0.9)]);
        System.out.println(srchReturn.toString()); 
        
        // Search for an element that is known not to exist (
//linear        
        srchReturn = Search.linear(testData1,999);
        System.out.println(srchReturn.toString());
        srchReturn = Search.linear(testData,9999);
        System.out.println(srchReturn.toString()); // display the performance info
        srchReturn = Search.linear(testData2,99999);
        System.out.println(srchReturn.toString()); 
//binary      
        srchReturn = Search.binary(testData1,999);
        System.out.println(srchReturn.toString());
        srchReturn = Search.binary(testData,9999);
        System.out.println(srchReturn.toString()); 
        srchReturn = Search.binary(testData2,99999);
        System.out.println(srchReturn.toString());
        
    }

    // this method will display the array contents if you want to view them
    private static void displayArray(int[] testData) {
        for (int theInt: testData) {
            System.out.print(theInt + ",");
        } System.out.println();
    }
}