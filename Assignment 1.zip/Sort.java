public class Sort {

    // Bubble sort is O(n^2)
    public static SortReturn bubble(int[] data) {
        long elements = data.length;
        long comparisons = 0; // track number of comparisons made while sorting
        long swaps = 0;       // track number of element swaps made while sorting

        long startTime = System.nanoTime(); // track processing time while sorting
        for (int i = 0; i<(int)elements-1; i++) {
            int min = i;
            for (int j = i+1; j < data.length; j++) {
                comparisons++; // if statement below represents a comparison
                if (data[j] < data[min]) {
                    swaps++; // this block is a swap
                    min = j;
                } 
                int temp = data[min];
                data[min] = data[i];
                data[i] = temp;
            } 
        }
        long totalTime = (System.nanoTime() - startTime); // capture final processing time

        // create return object to pass back all collected information
        SortReturn sr = new SortReturn("Bubble Sort",comparisons,swaps,totalTime,elements);
        return sr;
    }
    
    //Selection sort is O(n^2)
    public static SortReturn selection(int[] data) {
        long elements = data.length;
        long comparisons = 0; // track number of comparisons made while sorting
        long swaps = 0;       // track number of element swaps made while sorting

        boolean sorted = false;
        long startTime = System.nanoTime(); // track processing time while sorting
        while (!sorted) {
            sorted = true;
            for (int idx = 1; idx < data.length; idx++) {
                comparisons++; // if statement below represents a comparison
                if (data[idx] < data[idx-1]) {
                    swaps++; // this block is a swap
                    int tmpData = data[idx-1];
                    data[idx-1] = data[idx];
                    data[idx] = tmpData;
                    sorted = false;
                } 
            } 
        }
        long totalTime = (System.nanoTime() - startTime); // capture final processing time

        // create return object to pass back all collected information
        SortReturn sr = new SortReturn("Selection Sort",comparisons,swaps,totalTime,elements);
        return sr;
    }  
    
    //Insert sort is O(n*2) 
    public static SortReturn insert(int[] data) {
        long elements = data.length;
        long comparisons = 0; // track number of comparisons made while sorting
        long swaps = 0;       // track number of element swaps made while sorting

        long startTime = System.nanoTime(); // track processing time while sorting
        for (int i = 1; i<data.length; i++) { 
            int x = data[i];
            int j = i-1;
            comparisons++; // if statement below represents a comparison
            while (j >= 0 && data[j] > x) {
                swaps++; // this block is a swap
                data[j+1] = data[i];
                j -= 1;
            } 
            data[j+1]=x; 
        }
        long totalTime = (System.nanoTime() - startTime); // capture final processing time

        // create return object to pass back all collected information
        SortReturn sr = new SortReturn("Insert Sort",comparisons,swaps,totalTime,elements);
        return sr;
    }       
}

