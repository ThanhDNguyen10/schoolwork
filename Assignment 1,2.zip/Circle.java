/** 
Name: Thanh Nguyen
Date:9/10/20
Course: 206-205
Assignment: Assignment 2
Description: This class contain accessors and mutators with exception handling. It is also validate the user's input in the implementating class.
*/
public class Circle {
   //Instance variables
   private int x = 0;
   private int y = 0;
   private int radius = 0;
   private String color = "";
   
   
   //Accessors (get)
   public int getX() {return this.x;}      
   public int getY() {return this.y;}
   public int getRadius() {return this.radius;}
   public String getColor() {return this.color;}
   
   //Mutators (set)
   //Throw an argument for any invalid input
   //@param int x
   public void setX(int x) {
      if (x < 0 || x > 800) {
         throw new IllegalArgumentException("x has to be between 0-800.");
      } this.x = x;
   }    
   //@param int y
   public void setY(int y) {
      if (y < 0 || y > 600) {
         throw new IllegalArgumentException("y has to be between 0-600.");
      } this.y = y;
   }
   //@param int radius of the circle
   public void setRadius(int radius) {
      if (radius < 0 || radius > 100) {
         throw new IllegalArgumentException("Radius has to be between 0-100.");
      } this.radius = radius;
   }
   //Compare user's input of color and the given color
   //@param String color of the circle
   public void setColor(String color) {
      final String[] COLORS = {"red","green","blue"};
      String colorMatch ="";
      boolean found = false;
      int z = 0;
     
      while (!found && z < COLORS.length) {
         if (color.equals(COLORS[z])) {
            colorMatch = color;
            this.color = color;
            found = true;
         } else {
            ++z;
         }
       }
       if (colorMatch.equals("")) {
         throw new IllegalArgumentException(color + " can't be found.");
       }       
    }
    
    //@return X, Y, radius, and color of the circle
    public String toString() {
      return "X of the circle is " + this.getX()+"\nY of the circle is "+this.getY()+"\nRadius of the circle is "+this.getRadius()+"\nColor of the circle is "+this.getColor();
    }  
}    