/** 
Name: Thanh Nguyen
Date:9/10/20
Course: 206-205
Assignment: Assignment 2
Description: Implementation class of the Cirle. This is mainly use to prompt input from user. It will show error message if there's an error in validation.
Allow user to add more than 1 circle if wanted. Then, the program will output the result based on user's input.
*/
import javax.swing.JOptionPane;
public class CircleImplementation {
   public static void main (String[]args) {
      //Initialize the CircleDrawer class
      CircleDrawer cd = new CircleDrawer();
      
      //Create circle/s then output
      while(JOptionPane.showConfirmDialog(null,"Do you want to create a circle", null, JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) {
         Circle aCircle = createCircle();
         cd.addCircle(aCircle);
         cd.show();
      }
    }
    
    /**User's input of the circle's infos
    If user's input is wrong, program will output an error message
    Prompt again if user choose to create more circle
    @return a the Circle with user's input
    */
    public static Circle createCircle() {  
      //CircleDrawer cd = new CircleDrawer();
      
      Circle aCircle = new Circle();
      do {
         try {
            aCircle.setX(Integer.parseInt(JOptionPane.showInputDialog("Enter x of the circle: ")));   
         } catch(NumberFormatException e) { JOptionPane.showMessageDialog(null, e.getMessage()); }  
      } while (aCircle.getX() <= 0 || aCircle.getX() >= 800);      
      
      do {
         try {
            aCircle.setY(Integer.parseInt(JOptionPane.showInputDialog("Enter y of the circle: ")));   
         } catch(NumberFormatException e) { JOptionPane.showMessageDialog(null, e.getMessage()); }  
      } while (aCircle.getY() <= 0 || aCircle.getY() >= 600); 
      
      do {
         try {
            aCircle.setRadius(Integer.parseInt(JOptionPane.showInputDialog("Enter radius of the circle: ")));   
         } catch(NumberFormatException e) { JOptionPane.showMessageDialog(null, e.getMessage()); }  
      } while (aCircle.getRadius() <= 0 || aCircle.getRadius() >= 100); 
      
      do {
         try {
            aCircle.setColor(JOptionPane.showInputDialog("Enter color of the circle: "));   
         } catch(IllegalArgumentException e) { JOptionPane.showMessageDialog(null, e.getMessage()); }  
      } while (aCircle.getColor() == null  || aCircle.getColor().equals(""));   
      return aCircle;  
      
    }
}   