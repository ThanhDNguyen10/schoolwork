/** 
Name: Thanh Nguyen
Date:9/10/20
Course: 206-205
Assignment: Assignment 2
Description: This class allow you to create a circle shape with color.*/
import java.awt.*;
import javax.swing.*;
import java.util.*;

public class CircleDrawer {
   // height and width of the screen
   private int height = 600;
   private int width = 800;
   private JFrame f;
   private ArrayList<Circle> circles;

   public CircleDrawer() {
      f = new JFrame("CircleDrawer");
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      circles = new ArrayList<Circle>();
   }

   public void show() {
      JPanel p = new JPanel() {
          public void paintComponent(Graphics g) {
              for (Circle c: circles) {
                  if (c.getColor().equals("red")) {
                    g.setColor(Color.red);
                  }
                  if (c.getColor().equals("green")) {
                    g.setColor(Color.green);
                  }
                  if (c.getColor().equals("blue")) {
                    g.setColor(Color.blue);
                  }
                  int newx = c.getX() - c.getRadius();
                  int newy = c.getY() - c.getRadius();
                  g.fillOval(newx, newy, c.getRadius(), c.getRadius());
              }
          }
      };
      p.setPreferredSize(new Dimension(width, height));
      f.getContentPane().add(p);
      f.pack();
      f.show();

   }
   //@param Circle c
   public void addCircle(Circle c) {
      // later on, we will see why this is a bad idea!
      circles.add(c);      
   }
}
