/**
Name: Thanh Nguyen
Date: 2/9/21
Course: 306
Assignment: Assignment 0
Description: Implementation class that read excel file. Convert the String[] into Object array. Then, validate and calculate the number of each pets and average age of each.*/
import java.io.*;
import javax.swing.JOptionPane;

public class PetList {

    private static final String INPUT_FILE = "./pet_data.csv";
    private static final String OUTPUT_FILE = "./pet_report.txt";

    private static String[] petData;
    private static Pet[] pets;
    private static int numPets = 0;

    public static void main (String[] args) {
        retrievePetData();
        convertPetDataToPetObjects(petData);
        writeOutput();
    }
//Read csv file and store in an array
    private static void retrievePetData() {
        int incrementSize = 5;
        petData = new String[incrementSize];
       
        try (BufferedReader br = new BufferedReader(new FileReader(INPUT_FILE))) { 
            String line;
            while ((line = br.readLine()) != null) {
                petData[numPets] = line;
                numPets++;      
                if (numPets == petData.length) {
                    String[] tmpData = new String[petData.length + incrementSize];
                    for (int idx = 0; idx < petData.length; idx++) {
                        tmpData[idx] = petData[idx];
                    }
                    petData = tmpData;
                }
            }
            br.close();
        } catch (Exception e) {
            System.out.print(e.getClass().getName() + " ");
            System.out.println(e.getMessage());
        }
    }
//COnvert String array to Object array and validate the elements
//@array petData
    private static void convertPetDataToPetObjects(String[]petData) {
        int x =0;
        
        Pet[] pets = new Pet[numPets];
        String[] record=new String[petData.length]; 
/**        for(int n=0; n<numPets; n++) {
            if(record[n] == null) {
               record[n] = record[n++];
            }   
*/       
            for(String y:petData){
              if(y != null) {
                  record = y.split(",");
                 for (int a=0; a<2;a++){
                   if (record[a] == null) {
                     break;}
                 } 
              }
                                                      
                 boolean isDog = false;
                 boolean isCat = false;
                 if (record[0].equalsIgnoreCase("Dog")) {
                    isDog = true;
                 } else if (record[0].equalsIgnoreCase("Cat")) {
                    isCat = true;
                 }
                     String name = null;
                       if ((isDog || isCat) && !record[1].equals("")) {
                          name = record[1];
                       }
                       
                       int age = 0;
                       try {
                        if(record[2] == null || record[2].equals("")){
                           age =0;}
                        else {  age = Integer.parseInt(record[2]); }
                       } catch (NumberFormatException e) {
                       }
                       
                       if ((isDog || isCat) && name != null && age < 0) {
                          if (isDog){
                           pets[x] = new Dog(name, age);
                          }else if(isCat){
                           pets[x] = new Cat(name, age);
                          
                          } 
                       }        
                   
          }                                                 
    }
//Output the pet record to a text file
    private static void writeOutput () {
        try {
            PrintWriter pw = new PrintWriter(new FileOutputStream(OUTPUT_FILE)); 
            writePetObjects(pw);
            writePetStatistics(pw);
            pw.close();
        } catch (Exception e) {
            System.out.print(e.getClass().getName() + " ");
            System.out.println(e.getMessage());
        }
    }
//Validate the Object array
//@param pw
    private static void writePetObjects (PrintWriter pw) {
        if (pets != null) {
            for (Pet aPet: pets) {
                if (aPet != null) pw.println(aPet.toString()); 
            } 
        }
    }
//Track count of each pets and calculate the avg age of each
//@param pw
    private static void writePetStatistics (PrintWriter pw) {
        int numberOfCats = 0;
        int numberOfDogs = 0;
        float averageCatAge = 0.0f;
        float averageDogAge = 0.0f;
        int totalCatsAge = 0;
        int totalDogsAge = 0; 

        //Calc avg age
        for (int x =0; x<numPets; x++) {
         if (pets[x] instanceof Cat) {
            numberOfCats++;
            totalCatsAge += pets[x].getAge();
         }else{
            numberOfDogs++;
            totalDogsAge += pets[x].getAge();
         }   
        }
        
        averageCatAge = totalCatsAge/numberOfCats;       
        averageDogAge = totalDogsAge/numberOfDogs; 
        
        pw.println("Number of cats: " + numberOfCats);
        pw.println("Number of dogs: " + numberOfDogs);
        pw.println("Average cat age: " + averageCatAge);
        pw.println("Average dog age: " + averageDogAge);
               
    }

}
 