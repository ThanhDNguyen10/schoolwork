/**
Name: Thanh Nguyen
Date:2/9/21
Course: 306
Assignment: Assignment 0
Description: Parent abstract class*/
public abstract class Pet {
   private String name = "";
   private int age = 0;  
   
   //Constructor of pet
   //@param name,age
   public Pet (String name, int age) {
    this.name = name;
    this.age = age;
   }
   //Get name and age of the pet
   //@return name, age
   public String getName() {return this.name;}
   public int getAge() {return this.age;}
   //Set name of the pet
   //@param name
   public void setName(String name) {
      if (name == null || name.equals("")) { throw new IllegalArgumentException("Invalid name!"); }
      this.name = name;
   }
   //Set agge of the pet
   //@param age
   public void setAge(int age) {
      if (age < 0) { throw new IllegalArgumentException("Invalid age!"); }
      this.age = age;
   }
   //toString()
   //@return a string represent a pet
   public String toString() {
      return "Name: "+this.name+"\nAge: "+this.age;
      
   }   
}