/**
Name: Thanh Nguyen
Date:2/9/21
Course: 306
Assignment: Assignment 0
Description: Subclass extends of Pet, representing a cat*/
public class Cat extends Pet {
   public static String speak = "Meow";
   //Constructor of a cat
   //@param name, age
   public Cat (String name, int age) {
    super(name,age);
   }
   //toString()
   //@return a string represent a cat
   public String toString() {
      return super.toString() + "\nSpeak: "+speak;
      
   }   
}