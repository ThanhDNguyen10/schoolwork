/** 
Name: Thanh Nguyen
Date:10/14/20
Course: 206-205
Assignment: 6
Description: This is the parent class. This class consists of constructor, mutators, accessors, and special method. This class mainly for set inputs and validate user's inputs.
*/  
public class Registration {
   //Variables
   public static final String[] CLASSES = {"Freestyle", "Breaststroke", "Backstroke", "Butterfly"};
   public static final String[] ZONES = {"EAST", "WEST", "NORTH", "SOUTH"};
   private static final double rate = 100;
   private static final double rateButterfly = 150;
   
   private String name = "";
   private int age = 0;
   private String phone = "";
   private String email = "";
   
   private boolean isEnrolled;
   private String classes[] = new String[3];
   private int classCount = 0;
   private String zone = "";
   private double cost = 0.0;
   
   private static int countEnrolled = 0;
   private static int count = 0;
   
   //Constructor
   //@param name, age, phone, and email of a registered
   public Registration(String name, int age, String phone, String email) {
      this.name=name;
      this.age=age;
      this.phone=phone;
      this.email=email;
      
      count++;
   } 
   
   //Accessors 
   //@return name, age, phone, email, isEnrolled, number of registered, number of enrolled, zone of the classes, and cost of an enrolled
   public String getName() { return this.name;}     
   public int getAge() { return this.age;}
   public String getPhone() { return this.phone;}
   public String getEmail() { return this.email;}
   public boolean getIsEnrolled () {return this.isEnrolled; }
   public static int getCount() {return count;}
    
   public static int getCountEnrolled(){ return countEnrolled;}
   public String getZone() { return this.zone;}
   public double getCost() { return this.cost;}
   
   //Mutators set the value of each variables, validate and throw argument if input is invalid
   //@param name of a registered person
   public void setName(String name) { 
      if (name == null || name.equals("")){
         throw new IllegalArgumentException("Name is required");
      }
      this.name=name;
   }
   //@param age of a registered person
   public void setAge(int age) { 
      if (age < 10 || age > 18){
         throw new IllegalArgumentException("Age is required");
      }
      this.age=age;
   }
   //@param phone of a registered person
   public void setPhone(String phone) { 
      if (!checkPhone(phone)){
         throw new IllegalArgumentException("Invalid phone");
      }
      this.phone=phone;
   }
   //@param email of a registered person
   public void setEmail(String email) { 
      if (!checkEmail(email)){
         throw new IllegalArgumentException("Invalid email");
      }
      this.email=email;
   }
   //Increment classCount based on user's input
   //@param classes of an enrolled person
   public void setClasses(String classess) {
      if (classess == null || classess.equals("")) {
         throw new IllegalArgumentException("Invalid classes");
      }   
      this.classes[classCount]=classess;
      classCount++;
   }
   //@param zone of an enrolled person
   public void setZone(String zone) {
      if (zone == null || zone.equals("")) {
         throw new IllegalArgumentException("Invalid zone");
      }   
      this.zone=zone;
   }
   //@param countEnrolled1 allow other class's static method to access it
   public static void setCountEnrolled(int countEnrolled1) {
      countEnrolled=countEnrolled1;
   } 
   //@param isEnrolled - if the registered is enrolled or not
   public void setIsEnrolled(boolean isEnrolled) {this.isEnrolled=isEnrolled; } 
   
   //@return a string of classes based on user's input
   public String getClasss(){
      String classs="";
      for (int x=0; x<classCount; x++){
         classs +=classes[x];
         if (x < classCount-1) {
            classs +=", ";
         }
      }      
      return classs;
   }
   //increment number of enrolled and decrease the number of registered
   public static void enroll(){
      count--;
      countEnrolled++;}
       
   //Validate phone input
   //@param phone of a registered person
   //@return boolean
   private boolean checkPhone(String phone) {
      boolean correct = false;
      if (phone.length() == 11) {
         if (phone.charAt(3) == '.' && (phone.charAt(7)== '.')) {
            correct = true;
      }  }
      return correct;
   }  
   //Validate email input  
   //@param email of a registered person
   //@return boolean
   private boolean checkEmail(String email) {
      boolean correct = false;
      int position = email.indexOf("@");
      int index = email.indexOf(".");
      
      if (Character.isLetterOrDigit(email.charAt(0)) && (Character.isLetterOrDigit(email.charAt(1))) ) {
         if (position > 1 && (index > 2 ) && (Character.isLetterOrDigit(email.charAt(index+1))) && (Character.isLetterOrDigit(email.charAt(index+2)))) {
            correct = true;
         }  
      }
      return correct;
   } 
   
   //calculate the cost of an enrolled
   //@return cost
   public double calculateCost() {
      double cost = 0.0;
      for (int x =0; x<classCount; x++) {
         if (this.classes[x].equals(CLASSES[0]) || (this.classes[x].equals(CLASSES[1])) || (this.classes[x].equals(CLASSES[2]))) {
            cost += 100;
         }else if (this.classes[x].equals(CLASSES[3])) {
               cost +=150;
         }  
   }  return cost;}
   
   //toString method represent a string of a Registration object
   //@return a string of the registere with name, age, phone, and email
   public String toString() {
      return this.getName() +" | "+ this.getAge() +" | "+ this.getPhone() +" | "+ this.getEmail();
   }   
}               