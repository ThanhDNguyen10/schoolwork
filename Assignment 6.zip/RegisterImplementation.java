/** 
Name: Thanh Nguyen
Date:10/18/20
Course: 206-205
Assignment: Assignment 6
Description: Implementation class. This is mainly use to prompt input from user. Five options for user to choose. Each option corresponding to different methods.
User can choose to register, enroll, remove, and print selected. Any invalid input or out of bound will required the user to reprompt.
Maximum of 60 enrolled. Each method only execute 1 problem. If a registered has a sponsor, it will call the sponsor class.
*/
import javax.swing.JOptionPane;

public class RegisterImplementation {
   public static void main (String[] args) {
      
      int menuChoice = getMenuOption();
      final int MAX = 60;
      //creating a new registered array
      Registration[] collection = new Registration[MAX];
      //creating a new enrolled array
      Registration[] enrolled = new Registration[MAX];
      while (menuChoice !=5) {
         
         //Creating menu option
         switch(menuChoice) {
            case 1:
               register(collection);
               break;
            case 2:
               enroll(collection, Registration.getCount(), enrolled);
               break;
            case 3:
               removeEnrolled(collection, Registration.getCountEnrolled(), enrolled);
               break;
            case 4:
               print(collection, Registration.getCountEnrolled(), enrolled);
               break;
            default:
               throw new RuntimeException("Exit the program.");
         } menuChoice = getMenuOption(); 
      } 
    }
/**Ask user input for the menu option they want from 1-5     
@return the menu option */ 
    public static int getMenuOption() {
      int menuChoice;
      
      do {
         try {
            menuChoice = Integer.parseInt(JOptionPane.showInputDialog(
               "Enter your selection: " 
               + "\n(1) Register"
               + "\n(2) Enroll"
               + "\n(3) Remove enrolled"
               + "\n(4) Print selected record"
               + "\n(5) Exit the program"
            ));
         } catch (NumberFormatException e) {
            menuChoice = 0;
         }
         if (menuChoice < 1 || menuChoice > 5) {
            JOptionPane.showMessageDialog(null, "Invalid choice.");
         }
      } while (menuChoice<1 || menuChoice >5);
      return menuChoice;
   }
//This method will perform when user input 1 on menu. It will prompt user for the user's infos and store it in collection array.
//@param Registration[] collection- store user's input in an array   
   public static void register(Registration[] collection) {
      int position = Registration.getCount();
      if(position < collection.length) {
         try {
            String name = "";
            do {
               name = JOptionPane.showInputDialog("Name: "); 
               if (name == null || name.equals("")) {
                  JOptionPane.showMessageDialog(null, "Invalid name!"); }
            } while ((name == null) || (name.equals("")));      
                  
            int age = 0;
            do {
               age = Integer.parseInt(JOptionPane.showInputDialog("Age: "));
               if (age < 10 || age > 18) {
                  JOptionPane.showMessageDialog(null, "Invalid age!");
               }   
            } while (age < 10 || age > 18);
               
            String phone = "";   
            do{
               phone=JOptionPane.showInputDialog(null,"Enter phone number in XXX.XXX.XXXX format.");
               if((phone.length()!=12)||(phone.charAt(3) != '.') ||( phone.charAt(7) != '.')){
                  JOptionPane.showMessageDialog(null,"Please use the specified format");}
            }while((phone.length()!=12)||(phone.charAt(3) != '.') ||( phone.charAt(7) != '.'));

            String email = "";
            int positionAt =0;
            int index =0;
            do{
               email=JOptionPane.showInputDialog("Email: ");
               positionAt = email.indexOf("@");
               index = email.indexOf(".");
               if (!Character.isLetterOrDigit(email.charAt(0)) && (!Character.isLetterOrDigit(email.charAt(1))) && 
                  (positionAt < 2) || (index < 3 ) || (!Character.isLetterOrDigit(email.charAt(index+1))) || (!Character.isLetterOrDigit(email.charAt(index+2)))){
                  JOptionPane.showMessageDialog(null,"Invalid email!"); }
            }while(!Character.isLetterOrDigit(email.charAt(0)) && (!Character.isLetterOrDigit(email.charAt(1))) && 
                  (positionAt < 2) || (index < 3 ) || (!Character.isLetterOrDigit(email.charAt(index+1))) || (!Character.isLetterOrDigit(email.charAt(index+2))));
   
            boolean isSponsor = JOptionPane.showConfirmDialog(null, "Does this person has a sponsor?") == JOptionPane.YES_OPTION;  
            final Registration register;
            if (isSponsor) {
               String sponsor = JOptionPane.showInputDialog("Sponsor: ");
               double discount = Double.parseDouble(JOptionPane.showInputDialog("Discount: "));   
                  
               register = new Sponsor(name, age, phone, email, sponsor, discount);
            } else {
               register = new Registration (name, age, phone, email);
            }        
         collection[position] = register;
         } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "Can't be added. "+e.getMessage());
         }
      } else {   
         JOptionPane.showMessageDialog(null, "Collection is full.");
      }
   }
//This method will triggered when user input 2 form the menu. Input an index of a registered to enroll classes. 
//It will prompt user for the enrolled's classes and zone. Add the registered to enroll list and remove from register list
//@param Game[] collection-access collection array, int count-number of registered, Registration[] enrolled-enrolled array  
   public static void enroll(Registration[] collection, int count, Registration[] enrolled) {
      int counttemp =0;
      String list="", zone= "";
      String classes[]=new String[3];
      int index=0, i=0;
      int enrolledPosition = Registration.getCountEnrolled();
     
      for(int x=0; x<count; x++){
         list += "\nIndex " + x + " is " +collection[x];
      } 
       
         if (count <= 0) {  
            JOptionPane.showMessageDialog(null, "No one registered.");
         } else if (enrolledPosition>=enrolled.length) {
            JOptionPane.showMessageDialog(null, "Classes are full.");
         } else {
            index=Integer.parseInt(JOptionPane.showInputDialog("Enter index of the registered to enroll: \n"+list));
            enrolled[enrolledPosition]=collection[index];
               
               //enrolled's classes and zone
               do {
                  classes[i] = (String) JOptionPane.showInputDialog(null, "Which course/s you going to take?", "Only 3 classes allowed", JOptionPane.QUESTION_MESSAGE, null, Registration.CLASSES, Registration.CLASSES[0]);
                  i++;
                  counttemp++;
               } while ((JOptionPane.showConfirmDialog(null,"Do you want to add another class?", null, JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) && i<3);   
               zone = (String) JOptionPane.showInputDialog(null, "What is the camp zone?", "Only 1 zone allowed", JOptionPane.QUESTION_MESSAGE, null, Registration.ZONES, Registration.ZONES[0]);
               for (int n = 0; n <= counttemp-1; n++) {
                  enrolled[enrolledPosition].setClasses(classes[n]);
               }   
               counttemp=0;
               enrolled[enrolledPosition].setZone(zone);
               Registration.enroll();
               collection[index].getIsEnrolled();
         }
      //remove the registered from collection array once enrolled   
      if(collection[index].getIsEnrolled()) {
         collection[index] = collection[index++];
      }
   }          
   
   //Select an enrolled to remove from the list
   //@param Registration[] collection-accessing collection array, int countEnrolled - number of enrolled, Registration[] enrolled-enrolled array   
   public static void removeEnrolled(Registration[] collection, int countEnrolled, Registration[] enrolled) {
      String list ="";
      int index = 0;
      
      for(int x=0; x<countEnrolled; x++){
         list += "\nIndex " + x + " is " +enrolled[x];
      } 
      if (countEnrolled >= 0) {
         try {
            index = Integer.parseInt(JOptionPane.showInputDialog(list+"\nRemove an enrolled person by index: "));
         } catch (NumberFormatException e) {
            index = -1;
            if (index < 0 || index > countEnrolled) {
               JOptionPane.showMessageDialog(null, "Invalid index");
         }  }   
         
         //remove from the array and shift up 
         for (int x =index; x<countEnrolled-1; x++){
            enrolled[index]= enrolled[x+1];
         } 
         //Decrease the number of enrolled
         enrolled[index].setCountEnrolled(countEnrolled-1); 
      } else {
         JOptionPane.showMessageDialog(null,"There is no Enrolled person to be removed."); 
      }
   }
   
   //Print the selected infos
   //@param Registration[] collection-accessing collection array, int countEnrolled - number of enrolled, Registration[] enrolled-enrolled array
   public static void print(Registration[] collection, int countEnrolled, Registration[] enrolled) {
      String list ="";
      int index =0;
      
      for(int x=0; x<countEnrolled; x++){
         list += "\nIndex " + x + " is " +enrolled[x];
      } 
      if (countEnrolled > index) {
         try {
            index = Integer.parseInt(JOptionPane.showInputDialog(list+"\nPrint an enrolled person by index: "));
         } catch (NumberFormatException e) {
            index = -1;
            if (index < 0 || index > countEnrolled) {
               JOptionPane.showMessageDialog(null, "Invalid index");
         }  } 
      } else {  
         JOptionPane.showMessageDialog(null, "No enroll");   
      }
      String output = "Name  |  Age  |  Phone  |  Email"; 
      //output selected's infos with cost regardless discount
      JOptionPane.showMessageDialog(null, output+"\n"+ enrolled[index].toString() + "\nClasses: "+ enrolled[index].getClasss()+ "\nZone: "+ enrolled[index].getZone()+"\nCost: "+ enrolled[index].calculateCost());     
      }    
            
}   