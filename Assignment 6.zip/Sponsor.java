/**Thanh Nguyen
IT 206-005
Assignment: 6
Description: This subclass is an extend from the Registration class. In this class, it only have the info of a enrolled and sponsored.
It contains validation, set and get of the info for enrolled and sponsored. 
*/
public class Sponsor extends Registration {
   private String sponsor = "";
   private double discount = 0.0;

/**Create a construstor with superclass parameter and the parameter of sponsored
@param superclass parameters 
*/    
   public Sponsor(String name, int age, String phone, String email, String sponsor, double discount) {
      super(name, age, phone, email);
      this.sponsor=sponsor;
      this.discount=discount;
   }

/**Get the organization and discount from user 
@return the oragnization
@return discount
*/   
   public String getSponsor() {return this.sponsor; }
   public double getDiscount() {return discount; }

/**Validate the organization from user's input and set organization or throw exception if error
@param String organization
*/   
   public void setSponsor (String sponsor) {
      if (sponsor.equals("") || sponsor == null) {
         throw new IllegalArgumentException ("Invalid sponsor");
      }
      this.sponsor=sponsor;
   }
/**Validate the discount from user's input and set discount or throw exception if error
@param double discount
*/ 
   public void setDiscount (double discount) {
      if (discount<0.0 || discount>100.0) {
         throw new IllegalArgumentException ("Invalid discount");
      } 
      this.discount=discount;
   }    
   
   /**override superclass's toString method for a sponsored
      @return Call the toString of superclass and including the organization and discount for sponsored  
   */   
   public String toString() {
      return super.toString()+ "\n  Sponsor: "+sponsor+ "  |  Discount: "+discount+"\n ";
   }   
   
} 