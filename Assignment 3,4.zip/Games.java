/** 
Name: Thanh Nguyen
Date:9/25/20
Course: 206-205
Assignment: Assignment 4
Description: Implementation class of the Game. This is mainly use to prompt input from user. Six options for user to choose. Each option corresponding to different methods.
User can choose to add, remove, update, print by month, print all games. Any invalid input or out of bound will required the user to reprompt.
User can add up to 36 games for 2021-2022. Each method only execute 1 problem.
*/
import javax.swing.JOptionPane;
public class Games {
   public static void main (String[] args) {
      
      int menuChoice=getMenuOption();
      //Max of 36 games for 2021-2022
      final int MAX = 36;
      //creating a new Game array
      Game[] collection = new Game[MAX];
      
      
      while (menuChoice != 6) {
         
         //Creating menu option
         switch(menuChoice) {
            case 1:
               addGame(collection); //add game
               break;
            case 2:
               removeGame(collection, Game.getNumGame()); //remove
               break;
            case 3:
               updateGame(collection, Game.getNumGame()); //update
               break;
            case 4:
               printGame(collection, Game.getNumGame());  //print games of that month
               break;
            case 5:
               printGames(collection, Game.getNumGame()); //print all games
               break;   
            default:
               throw new RuntimeException("Unknown error in menu choice");
               
         }
         menuChoice = getMenuOption();   
      } 
    }
//list of menu choices and name of the menu
//@return menuChoice which is the number corresponding to an action
   public static int getMenuOption() {
      int menuChoice;
      
      do {
         try {
            menuChoice = Integer.parseInt(JOptionPane.showInputDialog(
               "Enter your selection: " 
               + "\n(1) Add game"
               + "\n(2) Remove game"
               + "\n(3) Update game"
               + "\n(4) Print game by given month"
               + "\n(5) Print games"
               + "\n(6) Exit the program"
            ));
         } catch (NumberFormatException e) {
            menuChoice = 0;
         }
         if (menuChoice < 1 || menuChoice > 6) {
            JOptionPane.showMessageDialog(null, "Invalid choice.");
         }
      } while (menuChoice<1 || menuChoice >6);
      return menuChoice;
   }
//This method will perform when user input 1. It will prompt user for the game's infos and store it.
//@param Game[] collection- store user's input in an array
   public static void addGame(Game[] collection) {
      int position = Game.getNumGame();
      
      if(position < collection.length) {
         try {
            Game aGame = new Game (
               JOptionPane.showInputDialog("Enter game's title: "), 
               Double.parseDouble(JOptionPane.showInputDialog("Enter game's MSRP: ")),  
               JOptionPane.showInputDialog("Enter game's rating: "+ Game.getRates()),   
               JOptionPane.showInputDialog("Enter game's month released: "+ Game.getMonths()));
         collection[position] = aGame;
         } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "Game can't be added. "+e.getMessage());
         }
      } else {   
         JOptionPane.showMessageDialog(null, "Collection is full.");
      }
   }
//After choosing option 2 from menu option, user required to input an index of a game that needed to be removed. Print no record if no added game.
//@param Game[] collection, numGame - delete an array from collection array and decrease number of game   
   public static void removeGame(Game[] collection, int numGame) {
      String list="";
      for(int x=0; x<numGame; x++){
         list += "\nIndex " + x + " is " +collection[x];
      } 
      if (numGame <= 0) {  
         JOptionPane.showMessageDialog(null, "No game scheduled.");
      } else {
         int index=Integer.parseInt(JOptionPane.showInputDialog("Enter index of the game to be remove: \n"+list));
            for (int x =index; x<numGame-1; x++){
               collection[index]= collection[x+1];
         } 
         collection[index].setNumGame(numGame-1); 
      }
   }
//Option 3 is update, user required to input an index of a game that needed to be updated. Print no record if no added game.
//@param Game[] collection, numGame - update the month of an array from collection array using numGame to check if there's scheduled game/s    
   public static void updateGame(Game[] collection, int numGame) {
      String list="";
      String monthReplace= "";
      if (numGame <= 0) {
         JOptionPane.showMessageDialog(null, "No game scheduled.");
      } else {
         for(int x=0; x<numGame; x++){
            list += "\nIndex " + x + " is " +collection[x];
         }  
         int index=Integer.parseInt(JOptionPane.showInputDialog("Enter index of the game that need an update: " + list));
         monthReplace = JOptionPane.showInputDialog("Enter rescheduled month: " +Game.getMonths());
         collection[index].setMonth(monthReplace);
      }  
   }   
/**Option 4 is print game/s for that specific month, user required to input a month then the program output the game/s that will be released that month.
And, print no record if no added game. If zero game released that month then print no game existed on that month */
//@param Game[] collection, numGame - print the game of that month from collection array using numGame to check if there's scheduled game/s    
   public static void printGame(Game[] collection, int numGame) {
      boolean match = false;
      int x =0;
      if (numGame<=0) {
         JOptionPane.showMessageDialog(null, "No record.");
      } else { 
         String theMonth = JOptionPane.showInputDialog("Enter month: " +Game.getMonths());
         
         for (int i=0; i<numGame; i++) {          
            if (theMonth.equals(collection[i].getMonth())) {
               match = true;
               JOptionPane.showMessageDialog(null, "Game scheduled for "+ theMonth+" is:\n"+ collection[i]);
            } else {
               match = false;
               
         }  }
      } 
      if (match == false) {
         JOptionPane.showMessageDialog(null, "No game existed on that month.");
      }     
   }
//Option 5 is print all games. And, print no record if no added game.
//@param Game[] collection, numGame - print all games from collection array using numGame to check if there's scheduled game/s       
   public static void printGames(Game[] collection, int numGame) {
      String output = "";
      if (numGame <= 0) {
         JOptionPane.showMessageDialog(null, "No record.");
      } else {
            
         for (int x = 0; x < numGame; x++) {
            output += "\n"+collection[x].toString();
         }
      JOptionPane.showMessageDialog(null, "Scheduled game/s: "+ output+ "\nTotal games: "+numGame);
      }      
   }     
}                          