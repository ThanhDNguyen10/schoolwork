/** 
Name: Thanh Nguyen
Date:9/25/20
Course: 206-205
Assignment: Assignment 4
Description: This class consists of constructor, mutators, accessors, and special method. This class mainly for set inputs and validate user's inputs.
*/
public class Game {
   private String title ="";
   private double MSRP = 0.0;
   private String rate;
   private String month;
   //RATING and MONTH can't be change and can be access in other class's static method
   public static final String[] RATING = {"Everyone", "Teen", "Mature"};
   public static final String[] MONTH = {"January", "February", "March", "April", "May",
                                          "June", "July", "August", "September", "October", 
                                          "November", "December"};
   //Count number of games
   private static int numGame=0;
   //Constructor
   //@param title, MSRP, rate, and month for the game
   public Game(String title, double MSRP, String rate, String month) {  
      if (!checkRate(rate)) {
         throw new IllegalArgumentException ("Rating must be one of the following: " + this.getRates());
      } 
      if (!checkMonth(month)) {
         throw new IllegalArgumentException ("Month must be one of the following: " + this.getMonths());
      }   
      
      this.title = title;  
      this.MSRP = MSRP; 
      this.rate = rate;  
      this.month = month;  
      //increase number of game after valid inputs
      numGame++;
   }
   //Accessors 
   //@return title, MSRP, rate, month, and numGame
   public String getTitle(){ return this.title;}
   public double getMSRP() {return this.MSRP;} 
   public String getRate(){ return this.rate;}   
   public String getMonth(){ return this.month;}   
   public static int getNumGame() {return numGame;}
   //@return a string of rates based on the RATING array
   public static String getRates(){
      String rates="";
      for (int x=0; x<RATING.length; x++){
         rates += RATING[x];
         if (x < RATING.length-1) {
            rates +=", ";
         }
      }      
      return rates;
   }
   //@return a string of months based on the MONTH array
   public static String getMonths(){
      String months="";
      for (int x=0; x<MONTH.length; x++){
         months += MONTH[x];
         if (x < MONTH.length-1) {
            months +=", ";
         }
      }      
      return months;
   }
   //Mutators set the value of each variables, validate and throw argument if input is invalid
   //@param numGame1 allow other class's static method to access it
   public static void setNumGame(int numGame1) {
      numGame=numGame1;
   }   
   //@param title of the game
   public void setTitle(String title){
      if (title == null || title.equals("")){
         throw new IllegalArgumentException("Invalid title.");
      }
      this.title=title;
   }
   //@param MSRP of the game
   public void setMSRP(double MSRP){
      if (MSRP < 0.0) {
         throw new IllegalArgumentException("Invalid MSRP.");                                            
      }
      this.MSRP=MSRP;
   }
   //@param rate of the game  
   public void setRate(String rate){
      if (!checkRate(rate)) {
         throw new IllegalArgumentException ("Rating must be one of the following: " + this.getRates());
      } 
      this.rate=rate;
   }
   //@param month of the game
   public void setMonth(String month) {
      if (!checkMonth(month)) {
         throw new IllegalArgumentException ("Month must be one of the following: " + this.getMonths());
      } 
      this.month = month;
   }
   //Validate user's input of the rate 
   //@param rate
   //@return boolean - true, if match, and false, if doesn't match.
   private boolean checkRate(String rate) {   
      int x= 0;
      boolean foundR = false;
      while (!foundR && x<RATING.length) {
         if (rate.equals(RATING[x])) {
            foundR = true;
         } else {
            x++;                                            
         } 
      }    
      return foundR;   
   }   
   //Validate user's input of the month
   //@param month
   //@return boolean - true, if match, and false, if doesn't match.   
   private boolean checkMonth(String month) {  
      int x= 0;
      boolean foundM = false;
      while (!foundM && x<MONTH.length) {
         if (month.equals(MONTH[x])) {
            foundM = true;
         } else {
            x++;                                            
         }
      }
      return foundM;
   }
   //@return a string of the game with title, MSRP, rate, and month
   public String toString() {
      return this.getTitle() +" | "+ this.getMSRP() +" | "+ this.getRate() +" | "+ this.getMonth();
   }   
}    