public class ArrayList306B<E> extends ArrayList306<E> implements List306B<E> {
    
    public void add(int i, E e) throws IndexOutOfBoundsException, IllegalStateException {
        // your code here
        if(size == data.length){increaseCapacity();  }
        for (int x=size-1; x>=i; x--)   
           data[x+1]=data[x];
        data[i]=e;
        size++;
    }
    
    public void increaseCapacity() throws IllegalStateException {
        // your code here
        int newSize = capacity()*2;
        
        E[] temp = (E[]) new Object[newSize];
        for(int i =0; i<size; i++) {
           temp[i] = data[i];
        }
        data= temp;
    }

    public void minimize() throws IllegalStateException {
        // your code here
        E[] temp = (E[]) new Object[size];
        for(int i =0; i<size; i++) 
           temp[i] = data[i];
        data= temp;
    }

    public int capacity() throws IllegalStateException {
        // your code here
        return data.length;   
    }
 
}