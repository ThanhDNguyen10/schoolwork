
public class ArrayList306<E> implements List306<E> {

    public static final int CAPACITY = 16;
    
    protected E[] data;
    protected int size = 0;

    public ArrayList306() { this(CAPACITY); }

    public ArrayList306(int capacity) {
        // your code here
        data = (E[])new Object[capacity];
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size ==0;
    }

    public E get(int i) throws IndexOutOfBoundsException {
        // your code here
        checkIndex(i,size);
        return data[i];
        
    }

    public E set(int i, E e) throws IndexOutOfBoundsException {
        // your code here
        checkIndex(i,size);
        E temp=data[i];
        data[i]=e; 
        return temp;   
    }

    public void add(int i, E e) throws IndexOutOfBoundsException, IllegalStateException {
        // your code here
        checkIndex(i,size+1);
        if(size == data.length){throw new IllegalStateException("Array is full");   }
        for (int x=size-1; x>=i; x--)   
           data[x+1]=data[x];
        data[i]=e;
        size++;
    }
        
    public E remove(int i) throws IndexOutOfBoundsException {
        // your code here
        checkIndex(i,size);
        E temp = data[i];
        
        for(int x =i; x<size-1; x++) {
            data[x]=data[x+1]; }
        data[size-1]=null;
        size--;   
        return temp;   
    }

    protected void checkIndex(int i, int n) throws IndexOutOfBoundsException {
        // your code here
        if (i<0||i>=n)
           throw new IndexOutOfBoundsException("Illegal index: "+i);
    }

}