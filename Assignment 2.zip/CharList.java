//import java.util.List;
public class CharList implements CharListable {
    
    private Node head;
    private Node tail;
          
    public void addToHead(char data) {
        Node newNode = new Node(data);
        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            head.prev = newNode;
            newNode.next = head;
            head = newNode; 
        }
    }

    public void addToTail(char data) {
        Node newNode = new Node(data);
        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
             tail= newNode;
        }
    } 
      
    public char remove() {
        char del = ' ';
        if (head == null || tail == null){
            throw new IllegalStateException();
        } else { 
           Node remove = head;
           head = head.next; 
           del = remove.data;
           
           return del;
        }  
    }

    public boolean isEmpty() {
        if (head == null || tail == null){
            return true;
        } else {
            return false; } 
    }

    public int size() {
       if (!isEmpty()) {
          Node temp = head;
          int count = 1;
          while (temp != tail) {
            count++;
            temp = temp.next;
          }
          return count;
       } else {
          return 0; 
       }       
    }
    
    public Node getHead() {
        return head;
    }    
    
    private void mergeSort(){
        if (this.size() <= 1) return;

        // Create lists for "left" and "right"
        CharList left = new CharList();
        CharList right = new CharList();
   
        // Divide into 2
        int mid = size() / 2;
        while (this.size() > mid) {
            left.addToHead(this.remove()); }
        while (!this.isEmpty()) {
            right.addToHead(this.remove()); }

        // recursively call mergeSort on the two halves
        left.mergeSort();
        right.mergeSort();

        // merge the two ordered halves back together in order
        while (!left.isEmpty() && !right.isEmpty()) {
            if (left.getHead().data < right.getHead().data) {
                this.addToTail(left.remove());          
            }else{ this.addToTail(right.remove()); }
        }

        // Add any leftovers from above (left and right may not be evenly distributed with high and low values)
        while (!left.isEmpty()) {
            this.addToTail(left.remove()); }
        while (!right.isEmpty()) {
            this.addToTail(right.remove()); }
    }
      
    private void quickSort() { 
         CharList L = new CharList();
         CharList E = new CharList();
         CharList G = new CharList();
         int n = this.size();
         if (n<2)return;
         int c =0;
         
         char pivot = head.data;
         while(!this.isEmpty()) {
            char element = this.remove();
            if (element<pivot) { c = -1;}
            if (c<0) {
               L.addToTail(element);
            }else if (c==0){   
               E.addToTail(element);
            }else{
               G.addToTail(element);
         }  }  
         L.quickSort();
         G.quickSort();
         
         while(!L.isEmpty()) {this.addToTail(L.remove()); }
         while(!E.isEmpty()) {this.addToTail(E.remove()); }
         while(!G.isEmpty()) {this.addToTail(G.remove()); }
                
    }     
     
    public void sort() { 
         mergeSort(); 
         quickSort();   
    }           
       
    public String toString() {
        if (isEmpty()) return "{}";
        else {
            Node currentNode = head;
            String returnValue = "{" + currentNode.data;
            while (currentNode.next != null) { 
                currentNode = currentNode.next;
                returnValue += "," + currentNode.data;
            }
            returnValue += "}";
            return returnValue;
        } 
    }

    /** Node class definition (inner class) **/

    private class Node {

        private Node prev;
        private Node next;
        private char data;

        private Node(char data) {
            this.data = data;
        }
    }
}