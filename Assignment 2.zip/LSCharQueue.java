public class LSCharQueue implements CharQueueable {
    
    private Node head;
    private Node tail;
      
    public void enqueue(char data) {
        Node newNode = new Node(data);
        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next=newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    } 

    public char dequeue() {
        char del = ' ';
        if (head == null ){
            throw new IllegalStateException();
        } else { 
           
           Node remove = head;
           head = head.next;
           if (head == tail){
               tail = tail.next;
               if (tail == null){
                  tail = head; }
           }          
           del = remove.data;
           
           return del;
        }  
    }

    public boolean isEmpty() {
        if (head == null){
            return true;
        } else {
            return false; } 
    }

    public int size() {
       if (!isEmpty()) {
          Node temp = head;
          int count = 0;
          while (temp == head|| temp == tail) {
            count++;
            temp = temp.next;
          }
          return count;
       } else {
          return 0; 
       }       
    }

    public char first() {    
        char ahead = ' '; 
        if (head == null){
            throw new IllegalStateException();
        } else { 
            Node first = head; 
            ahead = first.data;
            return ahead;
        }      
    }

    public String toString() {
        if (isEmpty()) return "{}";
        else {
            Node currentNode = head;
            String returnValue = "{" + currentNode.data;
            while (currentNode.next != null) { 
                currentNode = currentNode.next;
                returnValue += "," + currentNode.data;
            }
            returnValue += "}";
            return returnValue;
        } 
    }

    /** Node class definition (inner class) **/

    private class Node {

        private Node prev;
        private Node next;
        private char data;

        private Node(char data) {
            this.data = data;
        }
    }
}