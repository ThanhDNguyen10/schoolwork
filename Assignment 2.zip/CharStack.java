public class CharStack implements CharStackable {
    
    private Node head;
    private Node tail;
      
    public void push(char data) {
        Node newNode = new Node(data);
        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            head.prev = newNode;
            newNode.next = head;
            head = newNode;
        }
    }

    public char pop() {
        char del = ' ';
        if (head == null || tail == null){
            throw new IllegalStateException();
        } else { 
           
           Node remove = head;
           head = head.next; 
           
           del = remove.data;
           
           return del;
        }  
    }

    public boolean isEmpty() {
        if (head == null || tail == null){
            return true;
        } else {
            return false; } 
    }

    public int size() {
       if (!isEmpty()) {
          Node temp = head;
          int count = 1;
          while (temp != tail) {
            count++;
            temp = temp.next;
          }
          return count;
       } else {
          return 0; 
       }       
    }

    public char top() {    
        char ahead = ' '; 
        if (head == null || tail == null){
            throw new IllegalStateException();
        } else { 
            Node first = head; 
            ahead = first.data;
            return ahead;
        }      
    }

    public String toString() {
        if (isEmpty()) return "{}";
        else {
            Node currentNode = head;
            String returnValue = "{" + currentNode.data;
            while (currentNode.next != null) { 
                currentNode = currentNode.next;
                returnValue += "," + currentNode.data;
            }
            returnValue += "}";
            return returnValue;
        } 
    }

    /** Node class definition (inner class) **/

    private class Node {

        private Node prev;
        private Node next;
        private char data;

        private Node(char data) {
            this.data = data;
        }
    }
}